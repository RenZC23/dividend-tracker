(function () {
  'use strict';
  const M=window.TrackerModel,$=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
  const deployment=window.DIVIDEND_DEPLOYMENT||{},staticMode=deployment.mode==='static',D=window.TrackerDeployment,urls=D.endpoints(deployment,location.href);
  const KEY='dividend-tracker-v1',REFRESH_MS=30*60*1000;
  let state,editingId=null,toastTimer=null,refreshTimer=null,nextRead=0,confirmAction=null,pendingImport=null;
  let persistent=true,blockedStorage=false,marketPayload=null,marketPoll=null,refreshBusy=false;
  const filters={view:'all',signal:'all',sector:'all',sort:'default',query:''};
  const e=M.escape,icon=(id,cls='')=>`<svg class="icon ${cls}" aria-hidden="true"><use href="#i-${id}"/></svg>`;
  const dateToday=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  function toast(message,error=false) { clearTimeout(toastTimer);$('#toast').textContent=message;$('#toast').classList.toggle('error',error);$('#toast').hidden=false;toastTimer=setTimeout(()=>{$('#toast').hidden=true;},4000); }
  function load() {
    try {const raw=localStorage.getItem(KEY);return raw?M.normalizeState(JSON.parse(raw)):M.clone(window.DIVIDEND_SEED);}
    catch(error) {persistent=false;blockedStorage=true;toast('本地记录无法读取，已打开默认清单。原有存储尚未覆盖。',true);return M.clone(window.DIVIDEND_SEED);}
  }
  function save() {
    if(blockedStorage){toast('原有存储无法读取，修改暂存在本页。请导出备份保存。',true);$('#storage-status').textContent='· 仅暂存在本页';return false;}
    try {localStorage.setItem(KEY,JSON.stringify(state));persistent=true;$('#storage-status').textContent='';return true;}
    catch(error){persistent=false;$('#storage-status').textContent='· 保存失败，请导出备份';toast('浏览器保存失败，修改暂存在本页；请导出备份。',true);return false;}
  }
  function sourceText(s) {return s.quoteDate?`收盘 ${s.quoteDate}${s.marketData?.status==='stale'?' · 更新失败':''}`:'等待真实数据';}
  function renderCard(s) {
    const y=M.yieldOf(s),p=M.bandPosition(s),changeClass=s.change>0?'up':s.change<0?'down':'flat',fav=state.favorites.includes(s.id);
    const trend=['day','week','month'].map((k,i)=>`<span class="trend-pair"><label>${['日','周','月'][i]}</label><span class="trend-chip ${M.trendClass(s.trends[k])}">${e(s.trends[k])}</span></span>`).join('');
    const formatBand=b=>b?`${b[0].toFixed(2)} ~ ${b[1].toFixed(2)}`:'未设置';
    const buyHere=p?.inBuy?'现价在此':p?.belowBuy?'低于关注区':'';
    const sellHere=p?.inSell?'现价在此':p?.aboveSell?'高于回避区':'';
    const track=p?`<div class="position-track" role="img" aria-label="股价 ${s.price.toFixed(2)} 元在参考区间的位置">${p.buy?`<span class="track-buy" style="left:${p.buy[0]}%;width:${p.buy[1]-p.buy[0]}%"></span>`:''}${p.sell?`<span class="track-sell" style="left:${p.sell[0]}%;width:${p.sell[1]-p.sell[0]}%"></span>`:''}<span class="position-marker" style="left:${p.marker}%"></span></div>`:'';
    return `<article class="stock-card ${s.signal}" style="--card-light:${M.cardLightness(s)}%" data-stock="${e(s.id)}"><div class="card-top"><button class="stock-title" data-action="edit" data-id="${e(s.id)}" aria-label="查看和编辑${e(s.name)}"><h4>${e(s.name)}</h4><span class="stock-code">${e(s.code)} · ${e(s.sector)}</span></button><div class="card-badges"><span class="signal-badge">${M.SIGNALS[s.signal]}</span><button class="favorite-button ${fav?'on':''}" data-action="favorite" data-id="${e(s.id)}" aria-label="${fav?'取消自选':'加入自选'}${e(s.name)}" aria-pressed="${fav}">${icon('star')}</button></div></div><div class="card-price-line ${changeClass}"><strong class="card-price">${s.price===null?'—':'<span class="currency">¥</span>'+s.price.toFixed(2)}</strong><span class="change">${s.change===null?'待更新':(s.change>0?'+':'')+s.change.toFixed(2)+'%'}</span></div><div class="card-metrics"><div><label title="过去12个月已实施税前现金分红 / 收盘价">股息率<small>TTM</small></label><strong>${y===null?'—':y.toFixed(2)+'<small>%</small>'}</strong></div><span class="metric-divider"></span><div><label title="行情源提供的总市值，含对应总股本">市值</label><strong>${s.marketCap===null?'—':Number.isInteger(s.marketCap)?s.marketCap:s.marketCap.toFixed(1)}${s.marketCap===null?'':'<small>亿</small>'}</strong></div></div><div class="trend-row" title="BOLL(20,2) · 前复权收盘价 · 周/月截至最新收盘">${trend}</div><div class="bands"><div class="band"><span class="band-label">关注区</span><span class="band-values">${formatBand(s.buy)}</span>${buyHere?`<span class="band-here">${buyHere}</span>`:''}</div><div class="band"><span class="band-label">回避区</span><span class="band-values">${formatBand(s.sell)}</span>${sellHere?`<span class="band-here sell">${sellHere}</span>`:''}</div></div>${track}<div class="card-bottom"><span class="source-tag" title="${e(s.source+' · '+sourceText(s))}">${e(sourceText(s))}</span><button data-action="edit" data-id="${e(s.id)}" aria-label="编辑${e(s.name)}的参考数据">详情${icon('chevron')}</button></div></article>`;
  }
  function render() {
    const stat=M.stats(state),sectorNames=M.sectors(state.stocks);
    if(filters.sector!=='all'&&!sectorNames.includes(filters.sector))filters.sector='all';
    const rows=M.filterStocks(state,filters);
    $('#total-stat').textContent=stat.total;$('#sector-stat').textContent=`${stat.sectors} 个行业`;$('#follow-stat').textContent=stat.follow;
    $('#yield-stat').textContent=stat.averageYield===null?'—':stat.averageYield.toFixed(2);$('#yield-coverage').textContent=`${stat.yieldCount} 只有效TTM`;$('#favorite-stat').textContent=stat.favorites;
    $('#side-all-count').textContent=stat.total;$('#side-fav-count').textContent=stat.favorites;$('#tab-all-count').textContent=stat.total;$('#tab-fav-count').textContent=stat.favorites;
    $('#sector-select').innerHTML='<option value="all">全部行业</option>'+sectorNames.map(s=>`<option value="${e(s)}">${e(s)}</option>`).join('');$('#sector-select').value=filters.sector;
    $('#sector-options').innerHTML=sectorNames.map(s=>`<option value="${e(s)}"></option>`).join('');
    $('#sector-nav').innerHTML=sectorNames.map(s=>`<button data-sector="${e(s)}" class="${filters.sector===s?'active':''}">${e(s)}<span>${state.stocks.filter(x=>x.sector===s).length}</span></button>`).join('');
    $$('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===filters.view);b.setAttribute('aria-pressed',String(b.dataset.view===filters.view));});
    $$('[data-signal]').forEach(b=>{b.classList.toggle('active',b.dataset.signal===filters.signal);b.setAttribute('aria-pressed',String(b.dataset.signal===filters.signal));});
    $('#list-title').textContent=filters.view==='favorites'?'我的自选清单':'行业观察清单';$('#result-count').textContent=`${rows.length} 只股票`;
    const grouped=filters.sort==='default';
    $('#stock-list').innerHTML=grouped?sectorNames.map(s=>{const group=rows.filter(x=>x.sector===s);return group.length?`<section class="sector-section"><div class="sector-heading"><h3>${e(s)}</h3><span>${group.length} 只</span></div><div class="stock-grid">${group.map(renderCard).join('')}</div></section>`:'';}).join(''):`<section class="sector-section"><div class="stock-grid">${rows.map(renderCard).join('')}</div></section>`;
    $('#empty-state').hidden=rows.length>0;
    const noFav=filters.view==='favorites'&&stat.favorites===0;
    $('#empty-title').textContent=noFav?'你的自选清单还是空的':'没有找到匹配的股票';
    $('#empty-description').textContent=noFav?'点击股票卡片右上角的星标，加入日常观察。':'试试其他名称，或清除筛选条件。';
    $('#clear-filters').textContent=noFav?'浏览全部股票':'清除筛选';
    if(!persistent)$('#storage-status').textContent='· 仅暂存在本页';
  }
  function setView(view) {filters.view=view;render();}
  function localRead() {
    if(!blockedStorage&&persistent){try{const raw=localStorage.getItem(KEY);if(raw)state=M.normalizeState(JSON.parse(raw));}catch(error){toast('本地记录读取失败，保留当前清单。',true);}}
    M.mergeMarket(state,marketPayload);
  }
  function showMarketStatus(response) {
    const d=response?.data,p=response?.progress,available=state.stocks.filter(s=>s.marketData).length,failed=d?.errors?.length||0;
    const scheduleText=staticMode?'云端收盘后生成快照（计划16:23，可能延迟）':'每个工作日 16:15 收盘后更新';
    const overdue=staticMode&&d&&Date.now()-Date.parse(d.updatedAt)>4*86400000;
    $('#market-badge').textContent=available?'真实收盘数据':'等待行情连接';
    $('#notice-icon').textContent=failed?'注意':'收盘';
    $('#market-notice').textContent=p?.running?`正在更新 ${p.completed||0}/${p.total||state.stocks.length} 只股票，请稍候。`:
      d?`行情截至 ${d.latestQuoteDate} · 已接入 ${available}/${state.stocks.length} 只 · ${scheduleText}${failed?' · '+failed+' 项更新异常，详情可查看':''}${overdue?' · 快照超过4天未生成，请检查GitHub Actions':''}。标签和区间保留你的策略设置。`:staticMode?'尚未生成云端真实行情快照，请检查GitHub Actions；未取得数据的股票显示“—”。':'正在连接真实行情服务。尚无真实数据的股票显示“—”。';
    $('#read-status').textContent=p?.running?'更新中':d?'收盘行情 · '+d.latestQuoteDate:'等待数据';
    if(d?.updatedAt)$('#last-read').textContent=new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(d.updatedAt));
    $('#market-notice').parentElement.classList.toggle('has-error',failed>0||overdue);
  }
  async function refresh(showToast=true) {
    if(refreshBusy)return;refreshBusy=true;$('#refresh-button').classList.add('busy');$('#refresh-button').disabled=true;
    try{
      localRead();
      if(showToast&&!staticMode){const r=await fetch(urls.refresh,{method:'POST',headers:{'Content-Type':'application/json','X-Dividend-Client':'tracker'},body:JSON.stringify({codes:state.stocks.map(s=>s.code)}),signal:AbortSignal.timeout(12000)});if(!r.ok)throw new Error((await r.json()).error||'更新请求失败');}
      const r=await fetch(urls.market,{cache:'no-store',signal:AbortSignal.timeout(12000)});if(!r.ok)throw new Error('服务连接失败');
      const response=D.validateSnapshot(await r.json());marketPayload=response.data||marketPayload;M.mergeMarket(state,marketPayload);render();save();showMarketStatus(response);
      clearTimeout(marketPoll);if(response.progress?.running)marketPoll=setTimeout(()=>refresh(false),3000);
      if(showToast)toast(staticMode?'已读取云端最新快照；重新抓取由GitHub Actions完成。':response.progress?.running?'已开始更新真实数据，完成后会自动刷新页面。':'已读取最新真实收盘数据。');
    }catch(error){M.mergeMarket(state,marketPayload);render();$('#market-notice').textContent='行情服务暂时不可用，显示上次缓存的真实数据。请检查网络连接和服务运行状态。';$('#read-status').textContent='服务连接失败';if(showToast)toast(error.message,true);}
    finally{refreshBusy=false;$('#refresh-button').classList.remove('busy');$('#refresh-button').disabled=false;}
    if(state.settings.autoRefresh)nextRead=Date.now()+REFRESH_MS;
  }
  function syncAuto() {clearInterval(refreshTimer);$('#auto-refresh').checked=state.settings.autoRefresh;$('#countdown').hidden=!state.settings.autoRefresh;if(state.settings.autoRefresh){nextRead=Date.now()+REFRESH_MS;tick();refreshTimer=setInterval(tick,1000);}}
  function tick() {const left=nextRead-Date.now();if(left<=0){refresh(false);return;}const sec=Math.ceil(left/1000);$('#countdown').textContent=`${Math.floor(sec/60)}:${String(sec%60).padStart(2,'0')}`;}
  function clearFilters() {Object.assign(filters,{view:'all',signal:'all',sector:'all',sort:'default',query:''});$('#search').value='';$('#sort-select').value='default';render();}
  function openStock(id=null) {
    if(!id&&state.stocks.length>=M.MAX_STOCKS){toast('原型最多支持 500 只股票。',true);return;}
    editingId=id;const form=$('#stock-form');form.reset();$('#form-error').hidden=true;const s=id?state.stocks.find(x=>x.id===id):null;
    $('#dialog-eyebrow').textContent=s?'我的观察记录':'新增观察';$('#dialog-title').textContent=s?s.name:'添加股票';$('#dialog-subtitle').textContent=s?`${s.code} · ${s.sector} · 可修改参考数据与备注`:'填写参考数据，加入你的观察清单。';
    if(!s&&staticMode)$('#dialog-subtitle').textContent='仅支持云端跟踪清单中的股票；新代码需加入GitHub仓库的 tracked-codes.json 后更新快照。';
    $('#delete-button').hidden=!s;$('#detail-preview').hidden=!s;
    if(s){const y=M.yieldOf(s),q=s.marketData,d=q?.dividend;$('#detail-preview').innerHTML=`<b>${e(s.source)}</b> · 行情日期 ${e(s.quoteDate||'未取得')} ${q?.verified?'· 双源收盘价一致':''}<br>股息率 TTM ${y===null?'未知':y.toFixed(2)+'%'}；过去12个月税前现金分红 ${s.dividend===null?'—':s.dividend.toFixed(4)+'元/股'}<br>${d?`统计区间 (${e(d.start)}, ${e(d.end)}]；${d.events.length} 次已实施分红<br>`:''}${d?.events.map(event=>`${e(event.exDate)} · ${e(event.plan)}`).join('<br>')||''}<br>市值口径：${e(q?.marketCapBasis||'未核实')}<br>多周期：${e(q?.trends?.basis||'历史数据未取得')}<br><span class="strategy-note">关注/观望/回避与价格区间为你的策略参考，不随行情自动改写。</span>${q?.errors?.length?'<br>更新异常：'+e(q.errors.join('；')):''}${q?.lastError?'<br>最近失败：'+e(q.lastError):''}`;}
    const values=s?{name:s.name,code:s.code,sector:s.sector,signal:s.signal,price:s.price??'',change:s.change??'',dividend:s.dividend??'',marketCap:s.marketCap??'',buyLow:s.buy?.[0]??'',buyHigh:s.buy?.[1]??'',sellLow:s.sell?.[0]??'',sellHigh:s.sell?.[1]??'',day:s.trends.day,week:s.trends.week,month:s.trends.month,quoteDate:s.quoteDate??'',note:s.note}:{signal:'watch',day:'未设置',week:'未设置',month:'未设置'};
    for(const k of ['price','change','dividend','marketCap','quoteDate']){const field=form.elements.namedItem(k);field.readOnly=true;field.required=false;field.closest('label').classList.toggle('new-stock-hidden',!s);}
    for(const k of ['day','week','month']){const field=form.elements.namedItem(k);field.disabled=true;field.closest('label').classList.toggle('new-stock-hidden',!s);}
    form.elements.namedItem('code').readOnly=!!s;$('#computed-yield').hidden=!s;
    for(const [k,v]of Object.entries(values))form.elements.namedItem(k).value=v;
    form.elements.namedItem('favorite').checked=s?state.favorites.includes(s.id):true;updateComputedYield();$('#stock-dialog').showModal();
  }
  function closeStock() {$('#stock-dialog').close();editingId=null;}
  function updateComputedYield() {const f=$('#stock-form'),p=Number(f.elements.namedItem('price').value),raw=f.elements.namedItem('dividend').value;$('#computed-yield').textContent=p>0&&raw!==''&&Number(raw)>=0?`参考股息率：${(Number(raw)/p*100).toFixed(2)}%（按当前填写值计算）`:'参考股息率：—（需填写股价与年度现金分红）';}
  function saveStock(event) {
    event.preventDefault();const f=new FormData($('#stock-form'));const val=k=>String(f.get(k)||'').trim(),number=k=>val(k)===''?null:Number(val(k));
    try{
      const old=editingId?state.stocks.find(s=>s.id===editingId):null;
      if(!old&&!D.canAddCode(val('code'),deployment))throw new Error(staticMode?'此代码不在云端跟踪清单中。请先修改仓库 tracked-codes.json 并运行更新任务，再刷新网页添加。':'仅支持沪深 A 股 6 位代码。');
      if(state.stocks.some(s=>s.code===val('code')&&s.id!==editingId))throw new Error('该股票代码已在清单中，请编辑现有记录。');
      const band=(lo,hi)=>{const l=number(lo),h=number(hi);if(l===null&&h===null)return null;if(l===null||h===null)throw new Error('参考区间需同时填写上下限，或同时留空。');return [l,h];};
      const s={id:old?.id||val('code'),code:val('code'),name:val('name'),sector:val('sector'),signal:val('signal'),price:old?.price??null,change:old?.change??null,dividend:old?.dividend??null,marketCap:old?.marketCap??null,buy:band('buyLow','buyHigh'),sell:band('sellLow','sellHigh'),trends:old?.trends||{day:'未设置',week:'未设置',month:'未设置'},quoteDate:old?.quoteDate??null,note:val('note'),order:old?.order??(state.stocks.length?Math.max(...state.stocks.map(x=>x.order))+1:0),source:old?.source||'等待真实数据',dividendSource:old?.dividendSource||'未取得',marketManaged:true,marketData:old?.marketData||null};
      M.validateStock(s);const next=M.clone(state);if(old)next.stocks=next.stocks.map(x=>x.id===old.id?s:x);else next.stocks.push(s);
      next.favorites=next.favorites.filter(id=>id!==s.id);if(f.has('favorite'))next.favorites.push(s.id);state=M.normalizeState(next);M.mergeMarket(state,marketPayload);const saved=save();render();closeStock();if(saved)toast(`${s.name}已${old?'更新':staticMode?'加入观察清单，将读取云端快照':'加入观察清单，正在获取真实数据'}。`);if(!old)void refresh(true);
    }catch(error){$('#form-error').textContent=error.message;$('#form-error').hidden=false;$('#form-error').scrollIntoView({block:'nearest'});}
  }
  function askConfirm(title,message,action,label='确认') {confirmAction=action;$('#confirm-title').textContent=title;$('#confirm-message').textContent=message;$('#confirm-accept').textContent=label;$('#confirm-dialog').showModal();}
  function exportBackup() {
    const data={...state,exportedAt:new Date().toISOString(),app:'dividend-tracker'};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`股息追踪台备份-${dateToday()}.json`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('备份已导出，包含自选、参考区间和备注。');
  }
  async function importBackup() {
    const file=$('#import-file').files?.[0];$('#import-file').value='';if(!file)return;
    if(file.size>2000000){toast('备份文件过大，请选择 2MB 以内的 JSON 文件。',true);return;}
    try{pendingImport=M.normalizeState(JSON.parse(await file.text()));askConfirm('导入观察清单',`备份包含 ${pendingImport.stocks.length} 只股票、${pendingImport.favorites.length} 只自选。\n导入会替换当前浏览器的清单；建议先导出当前备份。`,()=>{state=pendingImport;pendingImport=null;blockedStorage=false;const saved=save();clearFilters();syncAuto();refresh(false);if(saved)toast('备份已导入。');},'导入并替换');}
    catch(error){toast(`导入失败：${error.message}`,true);}
  }
  $$('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
  $$('[data-signal]').forEach(b=>b.addEventListener('click',()=>{filters.signal=b.dataset.signal;render();}));
  $('#show-favorites').addEventListener('click',()=>setView('favorites'));
  $('#search').addEventListener('input',()=>{filters.query=$('#search').value;render();});
  $('#sector-select').addEventListener('change',()=>{filters.sector=$('#sector-select').value;render();});
  $('#sort-select').addEventListener('change',()=>{filters.sort=$('#sort-select').value;render();});
  $('#sector-nav').addEventListener('click',event=>{const b=event.target.closest('button[data-sector]');if(!b)return;filters.sector=filters.sector===b.dataset.sector?'all':b.dataset.sector;render();window.scrollTo({top:0,behavior:'smooth'});});
  $('#stock-list').addEventListener('click',event=>{const b=event.target.closest('button[data-action]');if(!b)return;const s=state.stocks.find(x=>x.id===b.dataset.id);if(!s)return;if(b.dataset.action==='edit'){openStock(s.id);return;}const index=state.favorites.indexOf(s.id);if(index===-1)state.favorites.push(s.id);else state.favorites.splice(index,1);const saved=save();render();if(saved)toast(`${s.name}${index===-1?'已加入':'已移出'}自选。`);});
  $('#clear-filters').addEventListener('click',clearFilters);$('#refresh-button').addEventListener('click',()=>refresh());
  $('#auto-refresh').addEventListener('change',()=>{state.settings.autoRefresh=$('#auto-refresh').checked;save();syncAuto();});
  $('#add-button').addEventListener('click',()=>openStock());$('#close-stock-dialog').addEventListener('click',closeStock);$('#cancel-stock-dialog').addEventListener('click',closeStock);
  $('#stock-form').addEventListener('submit',saveStock);$('#stock-form').addEventListener('input',updateComputedYield);
  $('#delete-button').addEventListener('click',()=>{const s=state.stocks.find(x=>x.id===editingId);if(!s)return;askConfirm('移出观察清单',`确定移出“${s.name}”吗？其参考数据、备注和自选状态会一并移除。`,()=>{state.stocks=state.stocks.filter(x=>x.id!==s.id);state.favorites=state.favorites.filter(id=>id!==s.id);const saved=save();closeStock();render();if(saved)toast(`${s.name}已移出清单。`);},'移出清单');});
  $('#confirm-accept').addEventListener('click',()=>{const action=confirmAction;confirmAction=null;$('#confirm-dialog').close();action?.();});$('#confirm-cancel').addEventListener('click',()=>{$('#confirm-dialog').close();confirmAction=null;pendingImport=null;});
  $('#confirm-dialog').addEventListener('cancel',()=>{confirmAction=null;pendingImport=null;});
  ['#help-button','#rules-button'].forEach(id=>$(id).addEventListener('click',()=>$('#help-dialog').showModal()));['#close-help-dialog','#help-done'].forEach(id=>$(id).addEventListener('click',()=>$('#help-dialog').close()));
  $('#export-button').addEventListener('click',exportBackup);$('#import-button').addEventListener('click',()=>$('#import-file').click());$('#import-file').addEventListener('change',importBackup);
  document.addEventListener('keydown',event=>{if(event.key==='/'&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)&&!$$('dialog').some(d=>d.open)){event.preventDefault();$('#search').focus();}});
  window.addEventListener('storage',event=>{if(event.key===KEY&&!$$('dialog').some(d=>d.open)){refresh(false);syncAuto();}});
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&state.settings.autoRefresh&&Date.now()>=nextRead)refresh(false);});
  for(const k of ['day','week','month'])$('#stock-form').elements.namedItem(k).innerHTML=M.TRENDS.map(t=>`<option value="${t}">${t}</option>`).join('');
  if(staticMode){$('#refresh-button span').textContent='读取最新快照';$('#refresh-button').title='读取已发布快照，不会在浏览器里重新抓取行情';}
  state=load();M.mergeMarket(state,null);render();void refresh(false);syncAuto();
  setInterval(()=>{if(document.visibilityState==='visible'&&!$$('dialog').some(d=>d.open))void refresh(false);},60000);
})();
