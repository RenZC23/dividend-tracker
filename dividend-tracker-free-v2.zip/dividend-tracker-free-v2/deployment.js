(function(root){
  'use strict';
  function endpoints(config={},href='http://localhost/'){return config.mode==='static'?{market:new URL(config.marketPath||'./market.json',href).href,refresh:null}:{market:new URL('/api/market',href).href,refresh:new URL('/api/refresh',href).href};}
  function canAddCode(code,config={}){return /^\d{6}$/.test(code)&&/^([036]|60|68)/.test(code)&&(config.mode!=='static'||config.codes?.includes(code));}
  function validateSnapshot(response){
    const d=response?.data;if(!d)return response;
    if(d.version!==1||!d.quotes||Array.isArray(d.quotes)||typeof d.quotes!=='object'||!Number.isFinite(Date.parse(d.updatedAt)))throw new Error('行情快照格式无效');
    for(const [code,q]of Object.entries(d.quotes)){
      if(q.code!==code||!/^\d{6}$/.test(code)||!(q.price>0)||!Number.isFinite(q.price)||!Number.isFinite(q.change)||!/^\d{4}-\d{2}-\d{2}$/.test(q.quoteDate))throw new Error('行情快照记录无效');
    }return response;
  }
  root.TrackerDeployment={endpoints,canAddCode,validateSnapshot};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.TrackerDeployment;
})(typeof window!=='undefined'?window:globalThis);
