import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import './data.js';

export const ROOT=path.dirname(fileURLToPath(import.meta.url));
export const DEFAULT_CODES=globalThis.DIVIDEND_SEED.stocks.map(s=>s.code);
export const STORE=process.env.DIVIDEND_DATA_DIR||path.join(ROOT,'runtime');
const DAY=86400000;
const finite=v=>v!==null&&v!==''&&Number.isFinite(Number(v));
const number=v=>finite(v)?Number(v):null;
export function chinaClock(now=new Date()) {
  const shifted=new Date(now.getTime()+8*3600000);
  return {date:shifted.toISOString().slice(0,10),hour:shifted.getUTCHours(),minute:shifted.getUTCMinutes(),weekday:shifted.getUTCDay()};
}
export function latestAllowedDate(now=new Date()) {
  const c=chinaClock(now);
  return c.hour<15 || (c.hour===15&&c.minute<10)?new Date(Date.parse(c.date+'T00:00:00Z')-DAY).toISOString().slice(0,10):c.date;
}
export function marketSymbol(code) {
  if(!/^\d{6}$/.test(code)||!/^([036]|60|68)/.test(code))throw new Error('仅支持沪深 A 股 6 位代码');
  return /^[569]/.test(code)?'sh'+code:'sz'+code;
}
export async function readJSON(name,fallback) {
  try{return JSON.parse(await fs.readFile(path.join(STORE,name),'utf8'));}
  catch(error){if(error.code==='ENOENT')return fallback;throw new Error(`${name} 无法读取，保留文件待检查：${error.message}`);}
}
export async function atomicJSON(name,data) {
  await fs.mkdir(STORE,{recursive:true});const temp=path.join(STORE,`${name}.${process.pid}.${randomUUID()}.tmp`);
  await fs.writeFile(temp,JSON.stringify(data,null,2),'utf8');await fs.rename(temp,path.join(STORE,name));
}
async function getJSON(url,attempt=0) {
  try {const response=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0 DividendTracker/1.0','Accept':'application/json','Referer':'https://finance.qq.com/'},signal:AbortSignal.timeout(20000)});if(!response.ok)throw new Error(`HTTP ${response.status}`);return await response.json();}
  catch(error){if(attempt<2){await new Promise(r=>setTimeout(r,700*(attempt+1)));return getJSON(url,attempt+1);}throw new Error(`${new URL(url).hostname}: ${error.message}`);}
}
export async function fetchEastmoneyDaily(code,cutoff) {
  const secid=(marketSymbol(code).startsWith('sh')?'1':'0')+'.'+code;
  const u=new URL('https://push2his.eastmoney.com/api/qt/stock/kline/get');
  u.search=new URLSearchParams({secid,klt:'101',fqt:'0',end:'20500101',lmt:'40',fields1:'f1,f2,f3,f4,f5,f6',fields2:'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61'});
  const json=await getJSON(u),d=json.data;if(json.rc!==0||d?.code!==code||!Array.isArray(d.klines)||!d.klines.length)throw new Error('东方财富未返回有效日线');
  const rows=d.klines.map(line=>{const a=line.split(',');return {date:a[0],open:number(a[1]),close:number(a[2]),high:number(a[3]),low:number(a[4]),change:number(a[8]),volume:number(a[5])};}).filter(r=>r.date<=cutoff&&r.close>0).sort((a,b)=>a.date.localeCompare(b.date));
  if(!rows.length)throw new Error('尚无可用收盘数据');const row=rows.at(-1);if(row.change===null)throw new Error('缺少收盘涨跌幅');return {...row,name:d.name,provider:'东方财富不复权日线'};
}
export async function fetchTencent(code,adjusted=true,count=650) {
  const symbol=marketSymbol(code),u=new URL('https://web.ifzq.gtimg.cn/appstock/app/fqkline/get');u.searchParams.set('param',`${symbol},day,,,${count},${adjusted?'qfq':''}`);
  const j=await getJSON(u),d=j.data?.[symbol],source=d?.[adjusted?'qfqday':'day']||d?.day;
  if(j.code!==0||!Array.isArray(source)||source.length<2)throw new Error('腾讯未返回有效历史日线');
  const rows=source.map(a=>({date:a[0],open:number(a[1]),close:number(a[2]),high:number(a[3]),low:number(a[4]),volume:number(a[5])})).filter(r=>/^\d{4}-\d{2}-\d{2}$/.test(r.date)&&r.close>0).sort((a,b)=>a.date.localeCompare(b.date));
  return {rows,qt:d.qt?.[symbol],adjusted:adjusted&&!!d.qfqday};
}
export async function fetchEastmoneyHistory(code){
  const u=new URL('https://push2his.eastmoney.com/api/qt/stock/kline/get');u.search=new URLSearchParams({secid:(marketSymbol(code).startsWith('sh')?'1':'0')+'.'+code,klt:'101',fqt:'1',end:'20500101',lmt:'650',fields1:'f1,f2,f3,f4,f5,f6',fields2:'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61'});
  const j=await getJSON(u);if(j.rc!==0||j.data?.code!==code||!Array.isArray(j.data.klines))throw new Error('备用前复权历史日线无效');
  const rows=j.data.klines.map(line=>{const a=line.split(',');return {date:a[0],open:number(a[1]),close:number(a[2]),high:number(a[3]),low:number(a[4]),volume:number(a[5])};}).filter(r=>r.close>0).sort((a,b)=>a.date.localeCompare(b.date));
  return {rows,adjusted:true,provider:'东方财富前复权历史日线'};
}
async function fetchQuoteBatch(codes){
  const result={};for(let offset=0;offset<codes.length;offset+=60){const group=codes.slice(offset,offset+60),url='https://qt.gtimg.cn/q='+group.map(marketSymbol).join(',');
    let response=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0'},signal:AbortSignal.timeout(20000)});if(!response.ok)throw new Error('腾讯行情批量接口 HTTP '+response.status);
    const text=new TextDecoder('gb18030').decode(await response.arrayBuffer());for(const match of text.matchAll(/v_(?:sh|sz)(\d{6})="([^"]*)"/g)){const values=match[2].split('~');if(values[2]===match[1])result[match[1]]=values;}
  }return result;
}
function qtDate(qt) {return /^\d{14}$/.test(qt?.[30]||'')?`${qt[30].slice(0,4)}-${qt[30].slice(4,6)}-${qt[30].slice(6,8)}`:null;}
export async function fetchClose(code,cutoff,qt) {
  const warnings=[];let primary=null;try{primary=await fetchEastmoneyDaily(code,cutoff);}catch(error){warnings.push(error.message);}
  const tqDate=qtDate(qt),tqPrice=number(qt?.[3]);
  if(primary){if(tqDate===primary.date&&tqDate<=cutoff&&tqPrice>0&&Math.abs(tqPrice-primary.close)>.011)throw new Error('两个行情源收盘价不一致，未发布新数据');return {...primary,warnings,crossChecked:tqDate===primary.date&&tqPrice>0};}
  const raw=await fetchTencent(code,false,40),rows=raw.rows.filter(r=>r.date<=cutoff),last=rows.at(-1),prev=rows.at(-2);if(!last||!prev)throw new Error('没有足够的不复权收盘日线');const q=raw.qt;
  // 除权日不能用前日未复权收盘价算涨跌幅，仅使用与收盘日匹配的行情字段。
  if(qtDate(q)!==last.date||!finite(q?.[32]))throw new Error('主行情源失败且无法核实除权日涨跌幅，继续保留旧数据');
  return {...last,name:q[1],change:Number(q[32]),provider:'腾讯不复权日线',warnings,crossChecked:false};
}
export function ttmStart(date) {
  const d=new Date(date+'T00:00:00Z'),month=d.getUTCMonth();d.setUTCFullYear(d.getUTCFullYear()-1);if(d.getUTCMonth()!==month)d.setUTCDate(0);return d.toISOString().slice(0,10);
}
export function calculateDividends(rows,asOf) {
  const start=ttmStart(asOf),events=[],seen=new Set();
  for(const r of rows){const date=String(r.EX_DIVIDEND_DATE||'').slice(0,10);if(r.ASSIGN_PROGRESS!=='实施分配'||!/^\d{4}-\d{2}-\d{2}$/.test(date)||date<=start||date>asOf)continue;
    const cash=number(r.PRETAX_BONUS_RMB),bonus=number(r.BONUS_RATIO)||0,transfer=number(r.IT_RATIO)||0;if(cash===null)throw new Error('已实施分红缺少现金金额，不能按零分红处理');if(cash<0||bonus<0||transfer<0)throw new Error('分红金额或送转比例无效');
    const reportDate=String(r.REPORT_DATE||'').slice(0,10),key=[date,reportDate,cash,bonus,transfer].join('|');if(seen.has(key))continue;seen.add(key);
    events.push({exDate:date,reportDate,cashPer10:cash,cashPerShare:cash/10,bonusPer10:bonus,transferPer10:transfer,plan:r.IMPL_PLAN_PROFILE||'',progress:r.ASSIGN_PROGRESS});
  }
  events.sort((a,b)=>a.exDate.localeCompare(b.exDate));let cash=0;for(const event of events){cash+=event.cashPerShare;cash/=1+(event.bonusPer10+event.transferPer10)/10;}
  return {amount:Number(cash.toFixed(8)),start,end:asOf,events,adjustment:'期间送转股后按当前股本折算；不含配股和股份回购'};
}
export async function fetchDividends(code,date) {
  let rows=[],page=1,pages=1;do{const u=new URL('https://datacenter-web.eastmoney.com/api/data/v1/get');u.search=new URLSearchParams({reportName:'RPT_SHAREBONUS_DET',columns:'ALL',filter:`(SECURITY_CODE="${code}")`,pageSize:'100',pageNumber:String(page),sortColumns:'EX_DIVIDEND_DATE',sortTypes:'-1'});
    const j=await getJSON(u);if(j.success!==true||j.code!==0||!j.result)throw new Error('东方财富分红接口未返回完整结果');const d=j.result.data;if(!Array.isArray(d)&&j.result.count!==0)throw new Error('分红记录缺失');if((d||[]).some(r=>r.SECURITY_CODE!==code))throw new Error('分红记录代码不匹配');rows.push(...(d||[]));pages=Math.max(1,Number(j.result.pages)||1);if(pages>10)throw new Error('分红页数异常');page++;
  }while(page<=pages);return {...calculateDividends(rows,date),provider:'东方财富已实施分红',fetchedAt:new Date().toISOString()};
}
export function bollinger(values) {
  if(values.length<20)return {label:'未设置',samples:values.length};const v=values.slice(-20),mid=v.reduce((a,b)=>a+b,0)/20,sd=Math.sqrt(v.reduce((a,b)=>a+(b-mid)**2,0)/20),close=v.at(-1),upper=mid+2*sd,lower=mid-2*sd,p=sd<1e-9?.5:(close-lower)/(upper-lower);
  const label=p>=1?'上':p<=0?'下':Math.abs(p-.5)<.025?'中':p>=.75?'中上偏上':p>.5?'中上偏下':p>=.25?'中下偏上':'中下偏下';return {label,close,mid,upper,lower,position:p,samples:20};
}
export function calculateTrends(rows,date) {
  const data=rows.filter(r=>r.date<=date),week=new Map(),month=new Map();for(const r of data){const d=new Date(r.date+'T00:00:00Z'),day=(d.getUTCDay()+6)%7;d.setUTCDate(d.getUTCDate()-day);week.set(d.toISOString().slice(0,10),r.close);month.set(r.date.slice(0,7),r.close);}
  return {day:bollinger(data.map(r=>r.close)),week:bollinger([...week.values()]),month:bollinger([...month.values()]),asOf:date,basis:'前复权收盘价，BOLL(20,2)，周/月含截至收盘的当前周期'};
}
async function fetchOne(code,previous,cutoff,batchQt) {
  const errors=[],warnings=[];let history=null;try{history=await fetchTencent(code,true,650);}catch(error){warnings.push('腾讯历史接口暂不可用，已尝试备用源');try{history=await fetchEastmoneyHistory(code);}catch(backupError){errors.push('多周期历史行情：'+backupError.message);}}
  const qt=batchQt||history?.qt,close=await fetchClose(code,cutoff,qt);if(previous?.quoteDate>close.date)throw new Error('数据源日期倒退，保留上次结果');
  let dividend=null;try{dividend=await fetchDividends(code,close.date);}catch(error){errors.push('分红：'+error.message);}
  const trends=history?.adjusted?calculateTrends(history.rows,close.date):previous?.quoteDate===close.date?previous.trends:null;if(history&&!history.adjusted)errors.push('未收到前复权历史行情，多周期位置暂不可用');
  const capDate=qtDate(qt),reportedCap=capDate===close.date?number(qt?.[45]):null;let marketCap=reportedCap>0?reportedCap:previous?.quoteDate===close.date?previous.marketCap:null,capBasis='腾讯行情总市值（含同一证券对应的总股本）';if(!(marketCap>0)){marketCap=null;errors.push('市值：行情日期与收盘日不一致，暂不展示');capBasis='未核实';}
  return {code,name:close.name,price:close.close,change:close.change,quoteDate:close.date,marketCap,marketCapBasis:capBasis,source:close.provider,verified:close.crossChecked,dividend,dividendAmount:dividend?.amount??null,dividendSource:dividend?'过去12个月已实施税前现金分红（除息日期口径）':'分红数据未取得',trends,historyCount:history?.rows.length??previous?.historyCount??0,historyProvider:history?.provider||'腾讯前复权历史日线',fetchedAt:new Date().toISOString(),errors:[...errors,...close.warnings],warnings,status:errors.length?'partial':'ok'};
}
export async function getCodes(extra=[]) {
  const saved=await readJSON('codes.json',{codes:DEFAULT_CODES});const codes=[...new Set([...saved.codes,...DEFAULT_CODES,...extra])];if(codes.length>500)throw new Error('跟踪股票最多500只');codes.forEach(marketSymbol);await atomicJSON('codes.json',{codes});return codes;
}
export async function updateMarket({codes=null,reason='manual',now=new Date(),onProgress=()=>{}}={}) {
  codes=codes||await getCodes();const old=await readJSON('market.json',{version:1,quotes:{}}),quotes={...old.quotes},errors=[],cutoff=latestAllowedDate(now),startedAt=new Date().toISOString();let completed=0,index=0;
  onProgress({running:true,total:codes.length,completed:0,startedAt});let batchQuotes={};try{batchQuotes=await fetchQuoteBatch(codes);}catch(error){console.error('批量行情备用：',error.message);}
  await Promise.all(Array.from({length:Math.min(4,codes.length)},async()=>{while(index<codes.length){const code=codes[index++];try{const q=await fetchOne(code,quotes[code],cutoff,batchQuotes[code]);quotes[code]=q;if(q.errors.length)errors.push({code,message:q.errors.join('；')});}catch(error){errors.push({code,message:error.message});if(quotes[code])quotes[code]={...quotes[code],status:'stale',lastError:error.message};}completed++;onProgress({running:true,total:codes.length,completed,startedAt});}}));
  const dates=codes.map(c=>quotes[c]?.quoteDate).filter(Boolean).sort();const payload={version:1,updatedAt:new Date().toISOString(),startedAt,reason,cutoff,latestQuoteDate:dates.at(-1)||null,earliestQuoteDate:dates[0]||null,total:codes.length,available:codes.filter(c=>quotes[c]).length,successful:codes.filter(c=>quotes[c]?.status==='ok').length,errors,quotes,schedule:{timezone:'Asia/Shanghai',time:'16:15',retryEveryMinutes:30,retryUntil:'19:00',catchUp:true},providers:['腾讯证券行情 / 前复权历史日线（东方财富备用）','东方财富不复权日线 / 已实施分红']};
  if(payload.available>0){await atomicJSON('market.json',payload);await fs.mkdir(path.join(STORE,'history'),{recursive:true});await atomicJSON(`history/${cutoff}.json`,payload);}await atomicJSON('status.json',{running:false,lastAttemptAt:payload.updatedAt,reason,total:codes.length,completed,status:errors.length?'partial':'ok',errors});onProgress({running:false,total:codes.length,completed});return payload;
}
