# 每日股息 · 免费在线版

方案：**GitHub Pages 静态网页 + GitHub Actions 每日收盘快照**。不用原电脑开机，不用买域名或服务器。标准 GitHub 托管 runner 在公开仓库运行免费；使用平台默认网址，在免费额度及使用规则范围内运行。

截至2026-11-12，免费 GitHub Pages 需公开仓库。本方案的网页、源码、默认股票与默认策略区间、公共行情快照是公开的；不含本机运行缓存、日志、浏览器自选/备注、个人备份及 Mac 服务设置。网页没有访问密码。不要上传持仓、账户、交易流水、密码或私人研究文件。你的网页编辑仍只保存在各自浏览器，不上传 GitHub。

## 你先做的一步

在 https://github.com/signup 注册免费个人账号，自己完成邮箱验证、验证码、密码和条款确认。不要把密码或邮箱验证码发给助手。注册并登录后告诉助手用户名；实际创建公开仓库及上传前确认公开内容。

## 部署步骤

1. 新建名为 `dividend-tracker` 的 **Public** 仓库，默认分支使用 `main`。
2. 上传本目录里的应用文件，包括隐藏目录 `.github`、`.gitignore`。`.github/workflows/pages.yml` 必须在仓库内；上传 ZIP 本身不能运行项目。只上传本部署目录，不上传原工作区。
3. 仓库 **Settings → Pages → Build and deployment → Source → GitHub Actions**。
4. 打开 **Actions → Update closing data and publish → Run workflow**，手动启动第一次部署。若平台要求启用 Actions，先启用。
5. 任务在云端获取真实数据、保存 `published/market.json`、构建网页并部署。完成后在 Pages 或部署任务中找到网址：`https://你的用户名.github.io/dividend-tracker/`。电脑和手机都打开同一地址。
6. 首次必须核对任务成功状态、页面行情日期和股票覆盖数；腾讯/东方财富能在本地访问不代表 GitHub runner 一定可访问。若云端源接口阻断、超时或限流，先排查任务日志，不能当作已上线成功。

## 每天更新与真实日期

工作日计划上海时间 **16:23** 抓取收盘数据，**17:23、18:23** 补试。Actions 使用 UTC 定时表达式 `23 8-10 * * 1-5`，和上海时间对应。不要据此承诺16:23准点上线：GitHub调度可能延迟，负载高时可能丢弃任务。行情取得后重新发布网页；浏览器“读取最新快照”只读已发布文件，不触发源接口。

云端已完整取得当天快照时补试跳过重复抓取；部分失败再试。完全没有抓到本次行情时任务失败，不替换上次在线页面。源数据只使用已收盘日，休市及停牌保留真实交易日期。未知分红不填零，原型示例行情从发布包移除。页面同时显示实际行情日期和快照生成时间，不把任务运行时间冒充收盘日期。超过4天无快照生成会显示提醒（长假也可能提醒）。

公开仓库60天无活动时，定时任务会被GitHub停用；本工作流正常更新会把公共行情文件提交到仓库，但不能承诺永久免维护。请留意 Actions 失败通知，并定期检查任务启用状态。任务可手动 Run workflow 重跑。

## 新增股票、自选和隐私

- 初始30只跟踪股票。新增云端行情代码要在仓库 `tracked-codes.json` 的 `codes` 数组加入沪深A股6位代码，保持不重复；提交后运行更新任务。
- 新快照上线后刷新网页，再“添加股票”填代码、名称和行业。页面会拒绝不在云端清单的代码，避免误认为新增股票会自动取得数据。
- 从网页删除股票仅删除此浏览器记录；停止云端抓取要从 `tracked-codes.json` 删除代码。
- 自选、备注、编辑区间仍按各自浏览器保存，不跨设备同步；可导出/导入JSON备份。**私人备份不要上传公开仓库**。
- 修改默认清单需要编辑源码；编辑自己的策略不改变默认公开清单。默认区间是现有策略参考，不是推荐买卖价。

## 费用比较（2026-11-12官方页面核对）

| 方案 | 基础费用 | 适合当前需求的条件 |
| --- | --- | --- |
| GitHub Pages + 公开仓库标准Actions | 免费额度内0美元/月 | 网页公开、收盘后快照；不保证准点 |
| Render常驻实例 + 1GB磁盘 | 实例7美元/月 + 磁盘0.25美元/月 = **7.25美元/月** | 保留原后台，密码保护，新增代码通过API登记 |

Render基础费用不包含可能的超额流量、税费、汇率、付费工作区及自购域名。当前 Hobby 页面列出5GB/月流量后0.15美元/GB；实际开通前仍要查看账单预览。无需购买高级工作区。付费方案依然可能受数据源、服务故障或地区网络影响，不是全天候可达保证。未开通任何付费服务。

Render免费后台会无请求15分钟后休眠且无永久磁盘，不适合把原常驻定时后台直接搬过去。本免费方案已改为独立云端任务，不用免费休眠服务。

## 开发及校验

Node.js22及以上，无第三方npm依赖：

```sh
npm test
node update-static.mjs
node build-static.mjs
```

网页输出在 `site/`，仅含HTML/CSS/浏览器JS及公共行情；每日保留最新快照于 `published/market.json`，历史版本保存在仓库提交里。不发布整个运行目录。

## 官方依据

- 免费Pages可用性：https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
- Actions公开仓库计费：https://docs.github.com/en/actions/concepts/billing-and-usage
- 调度延迟及60天停用：https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#schedule
- Pages限制：https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits
- Render现价：https://render.com/pricing
- Render免费限制：https://render.com/docs/free

跨地区和运营商访问需实测，不能保证任何网络都能打开；上线后应使用手机蜂窝网络测试。
