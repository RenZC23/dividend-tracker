(function (root) {
  'use strict';
  const SIGNALS = {follow:'关注',watch:'观望',avoid:'回避'};
  const TRENDS = ['未设置','下','中下偏下','中下偏上','中','中上偏下','中上偏上','上'];
  const MAX_STOCKS = 500;
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const clone = value => JSON.parse(JSON.stringify(value));
  const validNumber = (n,min,max) => typeof n==='number' && Number.isFinite(n) && n>=min && n<=max;
  const validText = (s,max) => typeof s==='string' && s.trim().length>0 && s.length<=max;
  const validDate = d => typeof d==='string' && /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d+'T00:00:00Z')) && new Date(d+'T00:00:00Z').toISOString().slice(0,10)===d;
  function validateStock(s) {
    if (!s || !validText(s.id,80) || !validText(s.name,30) || !/^\d{6}$/.test(s.code) || !validText(s.sector,20)) throw new Error('股票名称、6 位代码或行业信息不完整。');
    if ((s.price!==null&&!validNumber(s.price,0.01,100000)) || (s.change!==null&&!validNumber(s.change,-100,10000))) throw new Error('请填写有效的股价和涨跌幅。');
    if (s.dividend!==null && !validNumber(s.dividend,0,100000)) throw new Error('每股分红必须为非负数，或留空。');
    if (s.marketCap!==null && !validNumber(s.marketCap,0,1000000000)) throw new Error('市值必须为非负数，或留空。');
    if (!Object.hasOwn(SIGNALS,s.signal) || (s.quoteDate!==null&&!validDate(s.quoteDate))) throw new Error('参考标签或数据日期无效。');
    for (const key of ['buy','sell']) {
      const b=s[key];
      if (b!==null && (!Array.isArray(b) || b.length!==2 || !b.every(n=>validNumber(n,0.01,100000)) || b[0]>b[1])) throw new Error('参考区间需同时填写上下限，且下限不能大于上限。');
    }
    if (!s.trends || !['day','week','month'].every(k=>TRENDS.includes(s.trends[k]))) throw new Error('日、周、月位置标签无效。');
    if (typeof s.note!=='string' || s.note.length>1000) throw new Error('备注最多 1000 个字。');
    if (!validText(s.source,100) || !validText(s.dividendSource,200) || !validNumber(s.order,0,100000)) throw new Error('记录来源或排序信息无效。');
    return s;
  }
  function normalizeState(input) {
    if (!input || input.version!==1 || !Array.isArray(input.stocks) || input.stocks.length>MAX_STOCKS || !Array.isArray(input.favorites)) throw new Error('备份格式不正确，或股票数量超过 500 只。');
    const ids = new Set(),codes=new Set();
    const stocks = input.stocks.map(raw=>{
      const s = {id:raw.id,name:raw.name,code:raw.code,sector:raw.sector,price:raw.price,change:raw.change,dividend:raw.dividend,marketCap:raw.marketCap,signal:raw.signal,quoteDate:raw.quoteDate,source:raw.source,dividendSource:raw.dividendSource,note:raw.note,order:raw.order,buy:raw.buy===null?null:Array.isArray(raw.buy)?raw.buy.slice():raw.buy,sell:raw.sell===null?null:Array.isArray(raw.sell)?raw.sell.slice():raw.sell,trends:raw.trends?{day:raw.trends.day,week:raw.trends.week,month:raw.trends.month}:null,marketManaged:raw.marketManaged===true,marketData:null};
      if(raw.marketData&&raw.marketData.code===raw.code&&validNumber(raw.marketData.price,.01,100000)&&validNumber(raw.marketData.change,-100,10000)&&validDate(raw.marketData.quoteDate))s.marketData=clone(raw.marketData);
      validateStock(s);
      if(ids.has(s.id)||codes.has(s.code)) throw new Error('备份中包含重复的股票代码或标识。');
      ids.add(s.id);codes.add(s.code);return s;
    });
    if(input.favorites.some(id=>typeof id!=='string'||!ids.has(id))) throw new Error('备份中的自选股票与清单不一致。');
    return {version:1,stocks,favorites:[...new Set(input.favorites)],settings:{autoRefresh:input.settings?.autoRefresh===true}};
  }
  function mergeMarket(state,payload) {
    state.stocks=state.stocks.map(s=>{
      const q=payload?.quotes?.[s.code]||s.marketData;
      if(!q)return {...s,marketManaged:true,marketData:null,price:null,change:null,marketCap:null,dividend:null,quoteDate:null,source:'等待真实数据',dividendSource:'未取得',trends:{day:'未设置',week:'未设置',month:'未设置'}};
      return {...s,marketManaged:true,marketData:q,price:q.price,change:q.change,marketCap:q.marketCap??null,dividend:q.dividendAmount??null,quoteDate:q.quoteDate,source:q.source,dividendSource:q.dividendSource,trends:Object.fromEntries(['day','week','month'].map(k=>[k,q.trends?.[k]?.label||'未设置']))};
    });return state;
  }
  function yieldOf(s) { return s.dividend===null||!(s.price>0) ? null : s.dividend/s.price*100; }
  function sectors(stocks) {return [...new Set(stocks.slice().sort((a,b)=>a.order-b.order).map(s=>s.sector))];}
  function filterStocks(state,filters) {
    const query=(filters.query||'').trim().toLocaleLowerCase();
    const fav=new Set(state.favorites);
    const result=state.stocks.filter(s=>(filters.view!=='favorites'||fav.has(s.id)) && (filters.signal==='all'||s.signal===filters.signal) && (filters.sector==='all'||s.sector===filters.sector) && (!query||s.name.toLocaleLowerCase().includes(query)||s.code.includes(query)));
    const byYield=(a,b,direction)=>{const ay=yieldOf(a),by=yieldOf(b);if(ay===null&&by===null)return a.order-b.order;if(ay===null)return 1;if(by===null)return -1;return direction*(ay-by)||a.order-b.order;};
    const sorts={default:(a,b)=>a.order-b.order,'yield-desc':(a,b)=>byYield(a,b,-1),'yield-asc':(a,b)=>byYield(a,b,1),'change-desc':(a,b)=>(b.change??-Infinity)-(a.change??-Infinity)||a.order-b.order,'price-asc':(a,b)=>(a.price??Infinity)-(b.price??Infinity)||a.order-b.order,name:(a,b)=>a.name.localeCompare(b.name,'zh-CN')};
    return result.sort(sorts[filters.sort]||sorts.default);
  }
  function stats(state) {const ys=state.stocks.map(yieldOf).filter(y=>y!==null);return {total:state.stocks.length,follow:state.stocks.filter(s=>s.signal==='follow').length,favorites:state.favorites.length,sectors:sectors(state.stocks).length,averageYield:ys.length?ys.reduce((a,b)=>a+b,0)/ys.length:null,yieldCount:ys.length};}
  function bandPosition(s) {
    if(!(s.price>0)||(!s.buy&&!s.sell))return null;
    const nums=[...(s.buy||[]),...(s.sell||[])];const span=Math.max(...nums)-Math.min(...nums);const pad=span>0?span*.15:Math.max(s.price*.1,.1);
    const lo=Math.max(0,Math.min(...nums)-pad),hi=Math.max(...nums)+pad;
    const pct=n=>Math.max(0,Math.min(100,(n-lo)/(hi-lo)*100));
    return {marker:pct(s.price),buy:s.buy?[pct(s.buy[0]),pct(s.buy[1])]:null,sell:s.sell?[pct(s.sell[0]),pct(s.sell[1])]:null,inBuy:!!s.buy&&s.price>=s.buy[0]&&s.price<=s.buy[1],inSell:!!s.sell&&s.price>=s.sell[0]&&s.price<=s.sell[1],belowBuy:!!s.buy&&s.price<s.buy[0],aboveSell:!!s.sell&&s.price>s.sell[1]};
  }
  function cardLightness(s) {
    if(!(s.price>0))return 98;
    if(s.signal==='watch')return 99;
    if(s.signal==='follow'){const range=s.buy||[s.price*.8,s.price*1.2];const t=Math.max(0,Math.min(1,(range[1]-s.price)/Math.max(range[1]-range[0],.01)));return 91-t*6;}
    const range=s.sell||[s.price*.8,s.price*1.2];const t=Math.max(0,Math.min(1,(s.price-range[0])/Math.max(range[1]-range[0],.01)));return 96-t*8;
  }
  function trendClass(t) {return t==='上'?'top':t.startsWith('中上')?'high':t==='下'||t.startsWith('中下')?'low':'';}
  root.TrackerModel = {SIGNALS,TRENDS,MAX_STOCKS,escape,clone,validateStock,normalizeState,mergeMarket,yieldOf,sectors,filterStocks,stats,bandPosition,cardLightness,trendClass};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.TrackerModel;
})(typeof window!=='undefined'?window:globalThis);
