import fs from 'node:fs/promises';
import path from 'node:path';
import {ROOT,marketSymbol} from './market.mjs';

export const STATIC_ASSETS=['styles.css','model.js','deployment.js','app.js','icon.svg'];
export function cleanSeed(input=globalThis.DIVIDEND_SEED){
  const seed=structuredClone(input);seed.favorites=[];
  for(const stock of seed.stocks)Object.assign(stock,{price:null,change:null,dividend:null,marketCap:null,quoteDate:null,trends:{day:'未设置',week:'未设置',month:'未设置'},source:'等待真实数据',dividendSource:'未取得',marketManaged:true,marketData:null,note:''});
  return seed;
}
export async function trackedCodes(){
  const config=JSON.parse(await fs.readFile(path.join(ROOT,'tracked-codes.json'),'utf8'));
  if(!Array.isArray(config.codes)||!config.codes.length||config.codes.length>500||new Set(config.codes).size!==config.codes.length)throw new Error('云端跟踪代码需为1至500个不重复的沪深A股代码');
  config.codes.forEach(marketSymbol);return config.codes;
}
export function staticHTML(html,version=''){
  const old='电脑打开本地地址，手机同一Wi-Fi打开局域网地址。电脑需保持开机和联网，后台服务在用户登录后自动运行。行情由这台电脑统一更新，自选、区间和备注保存在各自浏览器，可以用备份转移。目前未部署公网，也未做账户云同步。';
  if(!html.includes(old))throw new Error('页面使用说明已变化，需检查静态版说明');
  return html.replace('<script src="./data.js" defer></script>',`<script src="./data.js?v=${version}" defer></script>`)
    .replace('<script src="./app.js" defer></script>',`<script src="./deployment-config.js?v=${version}" defer></script>\n  <script src="./app.js" defer></script>`)
    .replace(old,'电脑和手机打开同一在线HTTPS网址，不依赖原电脑开机。免费网页公开可访问；云端只发布公共行情及默认清单，不包含你的浏览器自选、备注或备份。定时任务计划16:23运行，17:23和18:23补试，可能排队或跳过。新增跟踪代码需修改仓库 tracked-codes.json；自选和策略仍按浏览器保存，可导出/导入转移，没有账户同步。')
    .replace('工作日 16:15 自动更新。','工作日收盘后由云端任务生成快照，可能延迟。')
    .replace('工作日16:15更新，失败后定时重试；启动时补更新。','云端计划上海时间16:23更新，17:23、18:23补试；免费任务可能延迟或跳过，页面明确显示实际行情日期。');
}
export function seedScript(seed){return "(function(root){root.DIVIDEND_SEED="+JSON.stringify(seed)+";})(typeof window!=='undefined'?window:globalThis);\n";}
export async function buildStatic(target=path.join(ROOT,'site'),snapshotOverride=null){
  target=path.resolve(target);if(target===ROOT||target===path.dirname(ROOT))throw new Error('不能将源码目录用作网页输出目录');
  await fs.mkdir(target,{recursive:true});
  for(const name of STATIC_ASSETS)await fs.copyFile(path.join(ROOT,name),path.join(target,name));
  const codes=await trackedCodes();
  await fs.writeFile(path.join(target,'index.html'),staticHTML(await fs.readFile(path.join(ROOT,'index.html'),'utf8'),String(codes.length)));
  await fs.writeFile(path.join(target,'data.js'),seedScript(cleanSeed()));
  await fs.writeFile(path.join(target,'deployment-config.js'),'window.DIVIDEND_DEPLOYMENT='+JSON.stringify({mode:'static',marketPath:'./market.json',codes})+';\n');
  const snapshot=snapshotOverride?Buffer.from(JSON.stringify(snapshotOverride)):await fs.readFile(path.join(ROOT,'published/market.json'));
  await fs.writeFile(path.join(target,'market.json'),snapshot);
  await fs.writeFile(path.join(target,'.nojekyll'),'');
  return target;
}
