import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {ROOT} from './market.mjs';
import {cleanSeed,seedScript} from './static-site.mjs';

const target=path.resolve(process.argv[2]||path.join(ROOT,'../dividend-tracker-free'));
if(target===ROOT||target.startsWith(ROOT+path.sep))throw new Error('导出目录必须在源码目录之外');
await fs.mkdir(target);
const files=['index.html','styles.css','model.js','deployment.js','app.js','icon.svg','market.mjs','static-site.mjs','update-static.mjs','build-static.mjs','tracked-codes.json','.gitignore','export-free.mjs','README-free.md','tests/market.test.mjs','tests/static.test.mjs'];
const hashes={};
async function write(name,bytes){const dest=path.join(target,name);await fs.mkdir(path.dirname(dest),{recursive:true});await fs.writeFile(dest,bytes);hashes[name]=createHash('sha256').update(bytes).digest('hex');}
for(const name of files)await write(name,await fs.readFile(path.join(ROOT,name)));
await write('data.js',seedScript(cleanSeed()));
await write('README.md',await fs.readFile(path.join(ROOT,'README-free.md')));
await write('.github/workflows/pages.yml',await fs.readFile(path.join(ROOT,'free-pages.yml')));
await write('free-pages.yml',await fs.readFile(path.join(ROOT,'free-pages.yml')));
await write('published/market.json',JSON.stringify({data:null,progress:{running:false},status:{status:'pending'}})+'\n');
await write('package.json',JSON.stringify({name:'dividend-tracker-free',version:'1.0.0',private:true,engines:{node:'>=22'},scripts:{test:'node tests/market.test.mjs && node tests/static.test.mjs',build:'node build-static.mjs',update:'node update-static.mjs'}},null,2)+'\n');
await write('publish-manifest.json',JSON.stringify({version:1,mode:'free-pages',files:hashes},null,2)+'\n');
console.log('已生成免费部署包：'+target+'\n不含本机行情、日志、个人备份和付费服务配置；首次云端任务抓取真实行情。');
