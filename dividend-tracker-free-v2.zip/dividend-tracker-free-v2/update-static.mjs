import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {ROOT,atomicJSON,updateMarket,latestAllowedDate} from './market.mjs';
import {trackedCodes} from './static-site.mjs';

export async function prepareSnapshot({codes,previous=null,now=new Date(),updater=updateMarket}={}){
  const cutoff=latestAllowedDate(now),old=previous?.data;
  const complete=old&&old.updatedAt.slice(0,10)<=cutoff&&codes.every(code=>old.quotes?.[code]?.quoteDate===cutoff&&old.quotes[code].status==='ok')&&!old.errors?.length;
  if(complete)return {response:previous,freshCount:codes.length,skipped:true};
  const data=await updater({codes,reason:'github-after-close',now});
  const freshCount=codes.filter(code=>data.quotes?.[code]&&data.quotes[code].status!=='stale'&&Date.parse(data.quotes[code].fetchedAt)>=Date.parse(data.startedAt)).length;
  if(!freshCount)throw new Error('本次没有抓取到真实行情，保留上次在线快照；请查看任务日志');
  return {freshCount,skipped:false,response:{data,progress:{running:false},status:{lastAttemptAt:data.updatedAt,status:data.errors.length?'partial':'ok',errors:data.errors}}};
}
async function main(){
  const codes=await trackedCodes();let previous=null;
  try{previous=JSON.parse(await fs.readFile(path.join(ROOT,'published/market.json'),'utf8'));}catch(error){if(error.code!=='ENOENT')throw error;}
  if(previous?.data)await atomicJSON('market.json',previous.data);
  const result=await prepareSnapshot({codes,previous});
  await fs.mkdir(path.join(ROOT,'published'),{recursive:true});
  await fs.writeFile(path.join(ROOT,'published/market.json'),JSON.stringify(result.response,null,2)+'\n');
  console.log(JSON.stringify({skipped:result.skipped,freshCount:result.freshCount,latestQuoteDate:result.response.data.latestQuoteDate,errors:result.response.data.errors},null,2));
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)await main();
