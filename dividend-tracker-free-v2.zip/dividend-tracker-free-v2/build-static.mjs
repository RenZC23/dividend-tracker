import {buildStatic} from './static-site.mjs';
console.log('静态网页已生成：'+await buildStatic(process.argv[2]));
